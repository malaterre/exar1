//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TButton *Button1;
        TEdit *QMax2;
        TMemo *Memo3;
        TCheckBox *Half;
        TButton *Button2;
        TSaveDialog *SaveDialog;
        TLabel *Label1;
        TMemo *Memo4;
        TEdit *MaxB;
        TLabel *Label2;
        TLabel *Label3;
        TEdit *insertB0;
        TCheckBox *interleaveb;
        void __fastcall Button1Click(TObject *Sender);
        void __fastcall Button2Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
