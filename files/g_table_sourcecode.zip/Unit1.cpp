//---------------------------------------------------------------------------

#include <vcl.h>
#include <vector>
#include <algorithm>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
    Button1Click(0);
}
//---------------------------------------------------------------------------
#include<sstream>
#include<math>

struct qvec{
    char x,y,z;
    int q_value;
    bool operator<(const qvec& rhs) const
    {
        if(q_value != rhs.q_value)
            return q_value < rhs.q_value;
        if(x != rhs.x)
            return x < rhs.x;
        if(y != rhs.y)
            return y > rhs.y;
        return z > rhs.z;
    }
};

void __fastcall TForm1::Button1Click(TObject *Sender)
{
   std::vector<qvec> data;
   int insertb0 = insertB0->Text.ToInt();
   int q2max = QMax2->Text.ToInt();
   for(int z = -8;z <= 8;++z)
   for(int y = -8;y <= 8;++y)
   for(int x = -8;x <= 8;++x)
   {
       if(insertb0 != 0 && x == 0 && y == 0 && z == 0)
           continue;
       if(Half->Checked)
       {
       if(x < 0)
           continue;
       if(x == 0 && y < 0)
           continue;
       if(x == 0 && y == 0 && z < 0)
           continue;
       }
       int q2 = x*x+y*y+z*z;
       if(q2 > q2max)
           continue;
       data.push_back();
       data.back().x = x;
       data.back().y = y;
       data.back().z = z;
       data.back().q_value = q2;
   }
   std::sort(data.begin(),data.end(),std::less<qvec>());
   double r = std::sqrt(data.back().q_value);
   double maxb = MaxB->Text.ToDouble();
   double ratio = maxb/r/r;

   if(interleaveb->Checked)
   {
       std::vector<int> pos(data.size());
       std::vector<qvec> new_data(data.size());
       pos[data.size() >> 1] = 1;
       new_data[data.size() >> 1] = data.back();
       for(int i = data.size()-2;i >= 0;--i)
       {
           int max_distance = 0;
           int max_pos = 0;
           for(int j = 0;j < data.size();++j)
           {
               if(pos[j])
                   continue;
               int distance = data.size();
               for(int k = 0; k < data.size();++k)
                   if( k != j && pos[k] && std::abs(j-k) < distance)
                       distance = std::abs(j-k);
               if(distance > max_distance)
               {
                   max_distance = distance;
                   max_pos = j;
               }
           }
           new_data[max_pos] = data[i];
           pos[max_pos] = 1;
       }
       new_data.swap(data);
   }
   if(insertb0)
   {
       std::vector<qvec> new_data;
       for(unsigned int i = 0,j = insertb0; i < data.size();++i,++j)
       {
           if(j == insertb0)
           {
                new_data.push_back();
                new_data.back().x = 0;
                new_data.back().y = 0;
                new_data.back().z = 0;
                new_data.back().q_value = 0;
                j = 0;
           }
           new_data.push_back(data[i]);
       }
       new_data.swap(data);
   }
   size_t qnum = data.size();
   data.resize(qnum);
   std::ostringstream out3,out4;
   out3.precision(10);
   out3.setf(std::ios::fixed);
   out3 << "[directions=" << qnum << "]" << std::endl;
   out3 << "CoordinateSystem=xyz" << std::endl;
   out3 << "Normalisation=none" << std::endl;
   out4.precision(10);
   out4.setf(std::ios::fixed);
   for(int i = 0; i < qnum;++i)
   {
       out3 << "Vector[" << i << "] = ( ";
       out3 << (double)data[i].x/r << ", " <<
              (double)data[i].y/r << ", " <<
              (double)data[i].z/r << " )" << std::endl;
       double q = std::sqrt(data[i].q_value);
       if(q == 0)
           out4 << (double)0 << "\t" << (double)0 << "\t" << (double)0 << "\t" << (double)0 << std::endl;
       else
           out4 << q*q*ratio << "\t" << (double)data[i].x/q << "\t" << (double)data[i].y/q << "\t" << (double)data[i].z/q << std::endl;
   }
   Memo3->Lines->Text = out3.str().c_str();
   Memo4->Lines->Text = out4.str().c_str();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button2Click(TObject *Sender)
{
    SaveDialog->InitialDir = ExtractFilePath(Application->ExeName);
    SaveDialog->FileName = ExtractFilePath(Application->ExeName) + "DiffusionVectors.txt";
    if(!SaveDialog->Execute())
        return;
    Memo3->Lines->SaveToFile(SaveDialog->FileName);
}
//---------------------------------------------------------------------------


